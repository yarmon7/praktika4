#include "simulatorwindow.h"
#include <QtWidgets>

SimulatorWindow::SimulatorWindow()
{
    setWindowTitle("Эмулятор БПЛА");
    auto *layout = new QVBoxLayout(this);
    layout->setContentsMargins(20, 18, 20, 18);
    layout->setSpacing(10);
    auto *status = new QLabel(this);
    status->setWordWrap(true);
    auto *toggle = new QPushButton(this);
    auto *rate = new QComboBox(this);
    rate->addItem("10 Гц", 100);
    rate->addItem("2 Гц", 500);
    rate->addItem("0,5 Гц", 2000);
    auto *form = new QFormLayout;
    form->addRow("Частота передачи", rate);
    layout->addLayout(form);
    layout->addWidget(toggle);
    auto *faults = new QGroupBox("Проверка отказов", this);
    auto *buttons = new QVBoxLayout(faults);
    auto *corrupt = new QPushButton("Повредить пакет");
    auto *skip = new QPushButton("Пропустить два пакета");
    auto *noAck = new QPushButton("Пропустить следующий ACK");
    auto *sensor = new QCheckBox("Отказ датчика высоты");
    buttons->addWidget(corrupt);
    buttons->addWidget(skip);
    buttons->addWidget(noAck);
    buttons->addWidget(sensor);
    layout->addWidget(faults);
    layout->addWidget(status);
    connect(&m_simulator, &Lab::UavSimulator::status, status, &QLabel::setText);
    auto refresh = [this, toggle, faults] {
        toggle->setText(m_simulator.running() ? "Отключить БПЛА" : "Подключить БПЛА");
        faults->setEnabled(m_simulator.running());
    };
    connect(toggle, &QPushButton::clicked, this, [this, refresh] {
        if (m_simulator.running()) m_simulator.stop();
        else m_simulator.start();
        refresh();
    });
    connect(rate, &QComboBox::currentIndexChanged, this, [this, rate] {
        m_simulator.setInterval(rate->currentData().toInt());
    });
    connect(corrupt, &QPushButton::clicked, &m_simulator, &Lab::UavSimulator::corruptNextPacket);
    connect(skip, &QPushButton::clicked, &m_simulator, &Lab::UavSimulator::skipTwoPackets);
    connect(noAck, &QPushButton::clicked, &m_simulator, &Lab::UavSimulator::suppressNextAck);
    connect(sensor, &QCheckBox::toggled, &m_simulator, &Lab::UavSimulator::setSensorFailed);
    m_simulator.start();
    refresh();
    resize(345, 290);
}
