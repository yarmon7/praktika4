#include "mavlinkmanager.h"
#include <QNetworkDatagram>
#include <cmath>

namespace Lab {
using Parser = MavlinkMessageParser;
namespace {
constexpr int WindowMs = 3000;
QString resultText(quint8 result)
{
    switch (result) {
    case 0: return "Команда принята";
    case 1: return "Команда временно отклонена";
    case 2: return "Команда отклонена";
    case 3: return "Команда не поддерживается";
    case 4: return "Ошибка выполнения команды";
    case 5: return "Команда выполняется";
    case 6: return "Команда отменена";
    default: return QString("Неизвестный результат %1").arg(result);
    }
}
}

MavlinkManager::MavlinkManager(TelemetryModel &model, QObject *parent)
    : QObject(parent), m_model(model)
{
    m_clock.start();
    m_qualityTimer.setInterval(1000);
    m_qualityTimer.setTimerType(Qt::PreciseTimer);
    m_silenceTimer.setSingleShot(true);
    m_silenceTimer.setTimerType(Qt::PreciseTimer);
    m_silenceTimer.setInterval(WindowMs + 1);
    m_ackTimer.setSingleShot(true);
    m_ackTimer.setTimerType(Qt::PreciseTimer);
    m_ackTimer.setInterval(3000);
    connect(&m_socket, &QUdpSocket::readyRead, this, &MavlinkManager::readPending);
    connect(&m_qualityTimer, &QTimer::timeout, this, &MavlinkManager::refreshQuality);
    connect(&m_silenceTimer, &QTimer::timeout, this, &MavlinkManager::loseLink);
    connect(&m_ackTimer, &QTimer::timeout, this, [this] { finishCommand("Подтверждение не получено"); });
}

bool MavlinkManager::start(quint16 port)
{
    if (isOpen()) return true;
    if (!m_socket.bind(QHostAddress::LocalHost, port, QUdpSocket::DontShareAddress)) {
        emit event("UDP", QString("Не удалось открыть порт %1 — %2").arg(port).arg(m_socket.errorString()));
        return false;
    }
    m_received = m_lost = m_errors = 0;
    m_address.clear();
    m_port = 0;
    m_firstPacket = {}; m_lastPacket = {};
    m_lastSeq = -1; m_lastArrival = -1;
    m_model.clear();
    m_commandStatus = "Команд ещё не было";
    m_qualityTimer.start();
    emit newStream();
    emit event("UDP", QString("Открыт порт %1").arg(m_socket.localPort()));
    emit changed();
    return true;
}
void MavlinkManager::stop()
{
    if (!isOpen()) return;
    m_qualityTimer.stop();
    m_silenceTimer.stop();
    m_socket.close();
    m_model.setConnected(false);
    m_recent.clear();
    m_rate = 0;
    if (m_pending) finishCommand("Ожидание отменено — канал закрыт");
    emit event("UDP", "Канал закрыт оператором");
    emit changed();
}
QString MavlinkManager::sender() const
{
    return m_address.isNull() ? QString("—") : QString("%1:%2").arg(m_address.toString()).arg(m_port);
}
Quality MavlinkManager::qualityFor(double rate, bool online)
{
    if (!online || rate < 1) return Quality::Low;
    return rate > 5 ? Quality::High : Quality::Medium;
}
void MavlinkManager::refreshQuality()
{
    const qint64 now = m_clock.elapsed();
    if (m_model.isConnected() && now - m_lastArrival > WindowMs) {
        loseLink();
        return;
    }
    while (!m_recent.empty() && m_recent.front() <= now - WindowMs) m_recent.pop_front();
    m_rate = double(m_recent.size()) * 1000 / WindowMs;
    emit changed();
}
void MavlinkManager::loseLink()
{
    if (!m_model.isConnected()) return;
    m_model.setConnected(false);
    m_lastSeq = -1;
    m_rate = 0;
    m_recent.clear();
    emit event("Связь", "Связь потеряна — более 3 с без корректных пакетов");
    emit changed();
    emit linkLost();
}
void MavlinkManager::readPending()
{
    while (m_socket.hasPendingDatagrams()) {
        const auto datagram = m_socket.receiveDatagram();
        if (!datagram.isValid() || !datagram.senderAddress().isLoopback()) continue;
        if (m_model.isConnected() &&
            (datagram.senderAddress() != m_address || datagram.senderPort() != m_port)) continue;
        QString error;
        const auto f = Parser::decode(datagram.data(), error);
        if (!f) {
            ++m_errors;
            emit event("Ошибка пакета", error);
            emit changed();
            continue;
        }
        if (f->system != UavId || f->component != UavComponent || f->type == Message::Command) continue;
        if (!m_model.isConnected() && f->type == Message::Ack) continue;
        const bool first = !m_model.isConnected();
        const bool recovered = first && m_lastPacket.isValid();
        const int step = m_lastSeq < 0 ? 1 : (f->seq - m_lastSeq + 256) % 256;
        ++m_received;
        const qint64 now = m_clock.elapsed();
        m_recent.push_back(now);
        m_lastArrival = now;
        m_lastPacket = QDateTime::currentDateTime();
        if (!m_firstPacket.isValid()) m_firstPacket = m_lastPacket;
        m_address = datagram.senderAddress();
        m_port = datagram.senderPort();
        m_silenceTimer.start();
        if (first) {
            m_model.clear();
            m_model.setConnected(true);
            emit newStream();
            emit event("Связь", recovered ? "Связь восстановлена" : "Связь установлена");
        }
        // Modulo-256 forward gaps. A duplicate or old frame must not rewind the model.
        if (step >= 1 && step < 128) {
            if (step > 1) {
                m_lost += step - 1;
                emit event("Потеря", QString("Пропущено пакетов: %1 (seq %2 → %3)")
                           .arg(step - 1).arg(m_lastSeq).arg(f->seq));
            }
            m_lastSeq = f->seq;
            switch (f->type) {
            case Message::Heartbeat: m_model.updateHeartbeat(Parser::heartbeat(*f)); break;
            case Message::Position: m_model.updatePosition(Parser::position(*f)); break;
            case Message::Ack: receiveAck(Parser::ack(*f)); break;
            case Message::Command: break;
            }
        }
        emit changed();
    }
}

void MavlinkManager::sendCommand(quint16 cmd, double altitude)
{
    if (m_pending) {
        emit event("Команда", "Предыдущая команда ожидает подтверждения");
        return;
    }
    if (!isOpen() || !m_model.isConnected() || m_clock.elapsed() - m_lastArrival > WindowMs) {
        finishCommand("Отправка невозможна — нет связи с БПЛА");
        return;
    }
    if ((cmd != Takeoff && cmd != Land) || !std::isfinite(altitude)
        || (cmd == Takeoff && (altitude < 10 || altitude > 500))) {
        finishCommand("Недопустимая команда или высота");
        return;
    }
    const auto bytes = Parser::encode({Message::Command, m_txSeq++, StationId, StationComponent,
                                       Parser::commandPayload(cmd, float(altitude))});
    if (m_socket.writeDatagram(bytes, m_address, m_port) != bytes.size()) {
        finishCommand("Ошибка отправки — " + m_socket.errorString());
        return;
    }
    m_pending = cmd;
    m_commandStatus = "WAITING_ACK — ожидание подтверждения";
    m_ackTimer.start();
    emit event("Команда", cmd == Takeoff ? QString("Взлёт (22) на %1 м — WAITING_ACK").arg(altitude)
                                         : QString("Посадка (21) — WAITING_ACK"));
    emit changed();
}
void MavlinkManager::receiveAck(const Ack &ack)
{
    if (!m_pending || *m_pending != ack.command
        || (ack.targetSystem && ack.targetSystem != StationId)
        || (ack.targetComponent && ack.targetComponent != StationComponent)) {
        emit event("ACK", "Получено подтверждение вне ожидаемой команды");
        return;
    }
    if (ack.result == 5) {
        m_commandStatus = resultText(ack.result);
        m_ackTimer.start();
        emit event("ACK", m_commandStatus);
        return;
    }
    finishCommand(resultText(ack.result));
}
void MavlinkManager::finishCommand(const QString &text)
{
    const QString detail = m_pending ? QString("COMMAND %1 — %2").arg(*m_pending).arg(text) : text;
    m_ackTimer.stop();
    m_pending.reset();
    m_commandStatus = text;
    emit event("Команда", detail);
    emit changed();
}
} // namespace Lab
