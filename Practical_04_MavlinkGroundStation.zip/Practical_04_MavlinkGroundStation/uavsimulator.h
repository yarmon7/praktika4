#pragma once
#include "telemetrymodel.h"
#include <QElapsedTimer>
#include <QTimer>
#include <QUdpSocket>

namespace Lab {
class UavSimulator : public QObject {
    Q_OBJECT
public:
    using Parser = MavlinkMessageParser;
    explicit UavSimulator(QObject *parent = nullptr);
    bool start(quint16 stationPort = StationPort, quint16 localPort = SimulatorPort);
    void stop();
    bool running() const { return m_timer.isActive(); }
    void setInterval(int ms);
    void corruptNextPacket() { m_corrupt = true; }
    void skipTwoPackets() { m_skip = 2; }
    void suppressNextAck() { m_omitAck = true; }
    void setSensorFailed(bool failed);
signals:
    void status(const QString &text);
private:
    void tick();
    void send(Message type, const QByteArray &payload);
    void readCommands();
    QUdpSocket m_socket;
    QTimer m_timer;
    QElapsedTimer m_boot, m_step;
    quint16 m_stationPort = StationPort;
    quint8 m_seq = 0;
    int m_skip = 0, m_untilHeartbeat = 0;
    bool m_corrupt = false, m_omitAck = false, m_failed = false;
    double m_height = 0, m_target = 0;
};
} // namespace Lab
