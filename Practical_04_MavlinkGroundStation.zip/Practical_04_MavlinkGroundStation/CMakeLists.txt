cmake_minimum_required(VERSION 3.16)
project(Practical_04_MavlinkGroundStation VERSION 1.0 LANGUAGES CXX)
set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_AUTOMOC ON)
set(CMAKE_AUTOUIC ON)
find_package(Qt6 REQUIRED COMPONENTS Widgets Network Charts)

add_library(mavlink_lab STATIC
    mavlinkmessageparser.cpp mavlinkmessageparser.h
    telemetrymodel.cpp telemetrymodel.h mavlinkmanager.cpp mavlinkmanager.h
    uavsimulator.cpp uavsimulator.h)
target_include_directories(mavlink_lab PUBLIC ${CMAKE_CURRENT_SOURCE_DIR})
target_link_libraries(mavlink_lab PUBLIC Qt6::Network)

add_executable(UavSimulator MACOSX_BUNDLE WIN32 simulator_main.cpp simulatorwindow.cpp simulatorwindow.h)
target_link_libraries(UavSimulator PRIVATE mavlink_lab Qt6::Widgets)
set(window_sources mainwindow.cpp mainwindow.h mainwindow.ui)
add_executable(Practical_04_MavlinkGroundStation MACOSX_BUNDLE WIN32 main.cpp ${window_sources})
target_link_libraries(Practical_04_MavlinkGroundStation PRIVATE mavlink_lab Qt6::Widgets Qt6::Charts)
add_dependencies(Practical_04_MavlinkGroundStation UavSimulator)

option(BUILD_TESTING "Build practical assignment tests" OFF)
if(BUILD_TESTING)
    enable_testing()
    find_package(Qt6 REQUIRED COMPONENTS Test)
    add_executable(practical04_tests MACOSX_BUNDLE tests/practical04_tests.cpp ${window_sources})
    target_link_libraries(practical04_tests PRIVATE mavlink_lab Qt6::Widgets Qt6::Charts Qt6::Test)
    add_dependencies(practical04_tests Practical_04_MavlinkGroundStation)
    add_test(NAME practical04 COMMAND practical04_tests)
    set_tests_properties(practical04 PROPERTIES ENVIRONMENT "QT_QPA_PLATFORM=offscreen")
endif()
