#include "telemetrymodel.h"
namespace Lab {
QString modeName(quint32 mode)
{
    switch (mode) {
    case Ground: return "На земле";
    case Climb: return "Набор высоты";
    case Hold: return "Удержание";
    case Descent: return "Снижение";
    default: return QString("Неизвестный (%1)").arg(mode);
    }
}
void TelemetryModel::updatePosition(Position position)
{
    m_position = position;
    emit positionChanged();
}
void TelemetryModel::updateHeartbeat(Heartbeat heartbeat)
{
    if (m_heartbeat && m_heartbeat->mode == heartbeat.mode
        && m_heartbeat->sensorFailed == heartbeat.sensorFailed) return;
    m_heartbeat = heartbeat;
    emit heartbeatChanged();
}
void TelemetryModel::clear()
{
    m_position.reset();
    m_heartbeat.reset();
    m_connected = false;
}
} // namespace Lab
