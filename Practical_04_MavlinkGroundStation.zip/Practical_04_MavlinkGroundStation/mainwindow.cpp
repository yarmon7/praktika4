#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QChart>
#include <QChartView>
#include <QDateTime>
#include <QDir>
#include <QLineSeries>
#include <QMessageBox>
#include <QValueAxis>
#include <cmath>

using namespace Lab;

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), ui(std::make_unique<Ui::MainWindow>()), m_link(m_model)
{
    ui->setupUi(this);
    initChart();
    connect(ui->btnStartLink, &QPushButton::clicked, this, [this]{ m_link.start(); });
    connect(ui->btnStopLink, &QPushButton::clicked, &m_link, &MavlinkManager::stop);
    connect(ui->btnSimulator, &QPushButton::clicked, this, &MainWindow::launchSimulator);
    connect(&m_simulator, &QProcess::stateChanged, this, &MainWindow::refresh);
    connect(&m_simulator, &QProcess::errorOccurred, this, [this]{
        addEvent("Эмулятор", m_simulator.errorString());
    });
    connect(ui->btnTakeoff, &QPushButton::clicked, this, [this]{
        m_link.sendCommand(Takeoff, ui->spinTakeoffAltitude->value());
    });
    connect(ui->btnLand, &QPushButton::clicked, this, [this]{ m_link.sendCommand(Land); });
    connect(&m_link, &MavlinkManager::changed, this, &MainWindow::refresh);
    connect(&m_link, &MavlinkManager::newStream, this, &MainWindow::resetStream);
    connect(&m_link, &MavlinkManager::event, this, &MainWindow::addEvent);
    connect(&m_model, &TelemetryModel::positionChanged, this, &MainWindow::updatePosition);
    connect(&m_model, &TelemetryModel::heartbeatChanged, this, &MainWindow::updateHeartbeat);
    connect(&m_link, &MavlinkManager::linkLost, this, [this] {
        if (m_lossWarningShown) return;
        m_lossWarningShown = true;
        QMessageBox::warning(this, "Связь потеряна", "Более трёх секунд нет данных от эмулятора.");
    }, Qt::QueuedConnection);
    refresh();
}

MainWindow::~MainWindow()
{
    if (m_simulator.state() != QProcess::NotRunning) {
        m_simulator.terminate();
        m_simulator.waitForFinished(1000);
    }
}
void MainWindow::launchSimulator()
{
    QDir bin(QCoreApplication::applicationDirPath());
#ifdef Q_OS_MACOS
    const QString program = bin.absoluteFilePath("../../../UavSimulator.app/Contents/MacOS/UavSimulator");
#elif defined(Q_OS_WIN)
    const QString program = bin.absoluteFilePath("UavSimulator.exe");
#else
    const QString program = bin.absoluteFilePath("UavSimulator");
#endif
    m_simulator.start(QDir::cleanPath(program), QStringList{});
}
void MainWindow::initChart()
{
    auto *chart = ui->chartView->chart();
    chart->setTitle("Высота и вертикальная скорость");
    chart->setMargins(QMargins(2, 4, 4, 2));
    chart->legend()->setAlignment(Qt::AlignBottom);
    m_altitude = new QLineSeries;
    m_speed = new QLineSeries;
    m_altitude->setName("Высота");
    m_speed->setName("Вертикальная скорость");
    m_altitude->setPen(QPen(QColor("#176ca3"), 2.5));
    m_speed->setPen(QPen(QColor("#be6620"), 2, Qt::DashLine));
    chart->addSeries(m_altitude);
    chart->addSeries(m_speed);
    m_timeAxis = new QValueAxis;
    m_timeAxis->setTitleText("Время, с");
    m_timeAxis->setLabelFormat("%.0f");
    m_timeAxis->setRange(0, 30);
    chart->addAxis(m_timeAxis, Qt::AlignBottom);
    m_altitudeAxis = new QValueAxis;
    m_altitudeAxis->setTitleText("Высота, м");
    m_altitudeAxis->setLabelFormat("%.0f");
    m_altitudeAxis->setRange(0, 10);
    chart->addAxis(m_altitudeAxis, Qt::AlignLeft);
    auto *speedAxis = new QValueAxis;
    speedAxis->setTitleText("Скорость, м/с");
    speedAxis->setRange(-10, 10);
    speedAxis->setLabelFormat("%.0f");
    speedAxis->setGridLineVisible(false);
    chart->addAxis(speedAxis, Qt::AlignRight);
    m_altitude->attachAxis(m_timeAxis);
    m_altitude->attachAxis(m_altitudeAxis);
    m_speed->attachAxis(m_timeAxis);
    m_speed->attachAxis(speedAxis);
    ui->chartView->setRenderHint(QPainter::Antialiasing);
}
void MainWindow::resetStream()
{
    m_altitude->clear();
    m_speed->clear();
    m_chartClock.start();
    m_timeAxis->setRange(0, 30);
    m_altitudeAxis->setRange(0, 10);
    for (QLabel *label : {ui->labelAltitude, ui->labelSpeed, ui->labelLatitude, ui->labelLongitude,
                          ui->labelFlightMode, ui->labelSensor}) label->setText("—");
}
void MainWindow::updatePosition()
{
    const auto &p = *m_model.position();
    ui->labelLatitude->setText(QString::number(p.latitude, 'f', 7) + "°");
    ui->labelLongitude->setText(QString::number(p.longitude, 'f', 7) + "°");
    ui->labelAltitude->setText(QString::number(p.altitude, 'f', 1) + " м");
    ui->labelSpeed->setText(QString::number(p.verticalSpeed, 'f', 1) + " м/с");
    const double t = m_chartClock.elapsed() / 1000.0;
    m_altitude->append(t, p.altitude);
    m_speed->append(t, p.verticalSpeed);
    while (m_altitude->count() > 300 || m_altitude->at(0).x() < t - 30) {
        m_altitude->remove(0); m_speed->remove(0);
    }
    m_timeAxis->setRange(std::max(0.0, t - 30), std::max(30.0, t));
    if (p.altitude > m_altitudeAxis->max())
        m_altitudeAxis->setMax(10 * std::ceil(p.altitude / 10));
}
void MainWindow::updateHeartbeat()
{
    const auto &h = *m_model.heartbeat();
    const QString mode = modeName(h.mode);
    const QString sensor = h.sensorFailed ? "Отказ" : "Исправен";
    if (ui->labelFlightMode->text() != mode) addEvent("Режим", mode);
    if (ui->labelSensor->text() != sensor)
        addEvent("Датчик", h.sensorFailed ? "Отказ датчика высоты" : "Датчик высоты исправен");
    ui->labelFlightMode->setText(mode);
    ui->labelSensor->setText(sensor);
}
void MainWindow::refresh()
{
    const bool online = m_model.isConnected();
    const bool open = m_link.isOpen();
    QString state = "Связь отсутствует";
    if (online) state = "Связь установлена";
    else if (open) state = m_link.lastPacket().isValid() ? "Связь потеряна" : "Ожидание БПЛА";
    ui->labelLinkStatus->setText(state);
    ui->labelLinkStatus->setStyleSheet(online ? "color:#228448;font-weight:bold"
                                               : "color:#bc4340;font-weight:bold");
    const auto quality = MavlinkManager::qualityFor(m_link.rate(), online);
    QString grade = "Низкое", color = "#bc4340";
    if (quality == Quality::High) { grade = "Хорошее"; color = "#228448"; }
    if (quality == Quality::Medium) { grade = "Среднее"; color = "#977000"; }
    ui->labelQuality->setText(QString("%1 · %2 пак/с").arg(grade).arg(m_link.rate(), 0, 'f', 1));
    ui->labelQuality->setStyleSheet("color:" + color + ";font-weight:bold");
    ui->labelSender->setText(m_link.sender());
    ui->labelTime->setText(m_link.lastPacket().isValid() ? m_link.lastPacket().toString("hh:mm:ss") : "—");
    ui->labelPackets->setText(QString("%1 / %2").arg(m_link.received()).arg(m_link.lost()));
    ui->labelErrors->setText(QString::number(m_link.errors()));
    ui->labelCommandStatus->setText(m_link.commandStatus());
    ui->btnStartLink->setEnabled(!open);
    ui->btnStopLink->setEnabled(open);
    ui->btnSimulator->setEnabled(m_simulator.state() == QProcess::NotRunning);
    ui->btnTakeoff->setEnabled(online && !m_link.waitingAck());
    ui->btnLand->setEnabled(ui->btnTakeoff->isEnabled());
}
void MainWindow::addEvent(const QString &type, const QString &text)
{
    ui->listCommandLog->insertItem(0, QString("%1   %2 · %3").arg(QTime::currentTime().toString("hh:mm:ss"), type, text));
    if (ui->listCommandLog->count() > 200) delete ui->listCommandLog->takeItem(200);
}
