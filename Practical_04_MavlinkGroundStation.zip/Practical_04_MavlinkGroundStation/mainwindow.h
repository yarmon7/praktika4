#pragma once
#include "mavlinkmanager.h"
#include <QElapsedTimer>
#include <QMainWindow>
#include <QProcess>
#include <memory>

namespace Ui { class MainWindow; }
class QLineSeries;
class QValueAxis;

class MainWindow : public QMainWindow {
    Q_OBJECT
public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow() override;
private:
    void initChart();
    void updatePosition();
    void updateHeartbeat();
    void refresh();
    void resetStream();
    void addEvent(const QString &type, const QString &text);
    void launchSimulator();
    std::unique_ptr<Ui::MainWindow> ui;
    Lab::TelemetryModel m_model;
    Lab::MavlinkManager m_link;
    QProcess m_simulator;
    QLineSeries *m_altitude = nullptr, *m_speed = nullptr;
    QValueAxis *m_timeAxis = nullptr, *m_altitudeAxis = nullptr;
    QElapsedTimer m_chartClock;
    bool m_lossWarningShown = false;
};
