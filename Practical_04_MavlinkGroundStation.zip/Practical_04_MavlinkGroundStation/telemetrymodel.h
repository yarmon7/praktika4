#pragma once
#include "mavlinkmessageparser.h"
#include <QObject>

namespace Lab {
enum FlightMode : quint32 { Ground, Climb, Hold, Descent };
QString modeName(quint32 mode);

class TelemetryModel : public QObject {
    Q_OBJECT
public:
    using QObject::QObject;
    const std::optional<Position> &position() const { return m_position; }
    const std::optional<Heartbeat> &heartbeat() const { return m_heartbeat; }
    bool isConnected() const { return m_connected; }
    void setConnected(bool connected) { m_connected = connected; }
    void updatePosition(Position position);
    void updateHeartbeat(Heartbeat heartbeat);
    void clear();
signals:
    void positionChanged();
    void heartbeatChanged();
private:
    std::optional<Position> m_position;
    std::optional<Heartbeat> m_heartbeat;
    bool m_connected = false;
};
} // namespace Lab
