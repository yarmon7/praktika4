#include "mavlinkmessageparser.h"
#include <QtEndian>
#include <cmath>
#include <cstring>
#include <limits>

namespace Lab {
namespace {
struct Definition { int size; quint8 crcExtra; };
std::optional<Definition> definition(Message id)
{
    switch (id) {
    case Message::Heartbeat: return Definition{9, 50};
    case Message::Position:  return Definition{28, 104};
    case Message::Command:   return Definition{33, 152};
    case Message::Ack:       return Definition{10, 143};
    }
    return {};
}
template<class T> T get(const QByteArray &bytes, int offset)
{
    return qFromLittleEndian<T>(bytes.constData() + offset);
}
template<class T> void put(QByteArray &bytes, int offset, T value)
{
    qToLittleEndian<T>(value, bytes.data() + offset);
}
quint8 byte(const QByteArray &data, int n) { return static_cast<quint8>(data[n]); }

quint16 checksum(QByteArrayView headerAndData, quint8 extra)
{
    quint16 crc = 0xffff;
    auto accumulate = [&crc](quint8 b) {
        quint8 temp = b ^ quint8(crc);
        temp ^= quint8(temp << 4);
        crc = (crc >> 8) ^ (quint16(temp) << 8) ^ (quint16(temp) << 3) ^ (temp >> 4);
    };
    for (char value : headerAndData) accumulate(quint8(value));
    accumulate(extra);
    return crc;
}
void putFloat(QByteArray &data, int offset, float value)
{
    quint32 bits;
    static_assert(sizeof(bits) == sizeof(value));
    std::memcpy(&bits, &value, sizeof(bits));
    put(data, offset, bits);
}
} // namespace

QByteArray MavlinkMessageParser::encode(const Frame &f)
{
    const auto def = definition(f.type);
    if (!def || f.payload.size() != def->size) return {};
    QByteArray payload = f.payload;
    while (payload.size() > 1 && payload.endsWith(char(0))) payload.chop(1);
    QByteArray data(10, 0);
    data[0] = char(0xfd);
    data[1] = char(payload.size());
    data[4] = char(f.seq);
    data[5] = char(f.system);
    data[6] = char(f.component);
    const quint32 id = static_cast<quint32>(f.type);
    data[7] = char(id); data[8] = char(id >> 8); data[9] = char(id >> 16);
    data += payload;
    const quint16 crc = checksum(QByteArrayView(data).sliced(1), def->crcExtra);
    data.append(char(crc));
    data.append(char(crc >> 8));
    return data;
}

std::optional<Frame> MavlinkMessageParser::decode(const QByteArray &data, QString &error)
{
    error.clear();
    if (data.size() < 12 || byte(data, 0) != 0xfd) {
        error = "Повреждён заголовок MAVLink 2";
        return {};
    }
    const int length = byte(data, 1);
    if (data.size() != 12 + length || !length) {
        error = "Неверная длина пакета";
        return {};
    }
    if (byte(data, 2) != 0) {
        error = "Неподдерживаемые флаги MAVLink 2";
        return {};
    }
    const auto id = Message(byte(data, 7) | (byte(data, 8) << 8) | (byte(data, 9) << 16));
    const auto def = definition(id);
    if (!def || length > def->size) {
        error = "Неизвестное сообщение или неверный размер полезной нагрузки";
        return {};
    }
    if (checksum(QByteArrayView(data).sliced(1, 9 + length), def->crcExtra)
        != get<quint16>(data, 10 + length)) {
        error = "Неверная контрольная сумма CRC";
        return {};
    }
    return Frame{id, byte(data, 4), byte(data, 5), byte(data, 6),
                 data.mid(10, length).leftJustified(def->size, char(0))};
}

QByteArray MavlinkMessageParser::heartbeatPayload(quint32 mode, bool failed)
{
    QByteArray p(9, 0);
    put(p, 0, mode);
    p[4] = 2;  // MAV_TYPE_QUADROTOR
    p[5] = 0;  // generic autopilot, simulator-defined custom modes
    p[6] = 1;  // MAV_MODE_FLAG_CUSTOM_MODE_ENABLED
    p[7] = failed ? 5 : 4; // MAV_STATE_CRITICAL / ACTIVE
    p[8] = 3;  // heartbeat protocol version
    return p;
}
QByteArray MavlinkMessageParser::positionPayload(const Position &v)
{
    QByteArray p(28, 0);
    put(p, 0, v.bootMs);
    put(p, 4, qint32(std::llround(v.latitude * 1e7)));
    put(p, 8, qint32(std::llround(v.longitude * 1e7)));
    const qint32 height = qint32(std::llround(v.altitude * 1000));
    put(p, 12, height);  // simulated reference ground at 0 m MSL
    put(p, 16, height);
    put(p, 24, qint16(std::lround(-100 * v.verticalSpeed))); // NED, cm/s down
    put(p, 26, quint16(0xffff)); // heading unknown
    return p;
}
QByteArray MavlinkMessageParser::commandPayload(quint16 id, float altitude)
{
    QByteArray p(33, 0);
    for (int offset : {12, 16, 20}) putFloat(p, offset, std::numeric_limits<float>::quiet_NaN());
    putFloat(p, 24, altitude);
    put(p, 28, id);
    p[30] = char(UavId); p[31] = char(UavComponent);
    return p;
}
QByteArray MavlinkMessageParser::ackPayload(quint16 command, quint8 result, quint8 sys, quint8 comp)
{
    QByteArray p(10, 0);
    put(p, 0, command);
    p[2] = char(result); p[8] = char(sys); p[9] = char(comp);
    return p;
}
Heartbeat MavlinkMessageParser::heartbeat(const Frame &f)
{
    return {get<quint32>(f.payload, 0), byte(f.payload, 7) >= 5 && byte(f.payload, 7) <= 7};
}
Position MavlinkMessageParser::position(const Frame &f)
{
    return {get<quint32>(f.payload, 0), get<qint32>(f.payload, 4) / 1e7,
            get<qint32>(f.payload, 8) / 1e7, get<qint32>(f.payload, 12) / 1000.0,
            -get<qint16>(f.payload, 24) / 100.0};
}
Command MavlinkMessageParser::command(const Frame &f)
{
    const quint32 bits = get<quint32>(f.payload, 24);
    float altitude;
    std::memcpy(&altitude, &bits, sizeof(bits));
    return {get<quint16>(f.payload, 28), altitude, byte(f.payload, 30), byte(f.payload, 31)};
}
Ack MavlinkMessageParser::ack(const Frame &f)
{
    return {get<quint16>(f.payload, 0), byte(f.payload, 2), byte(f.payload, 8), byte(f.payload, 9)};
}
} // namespace Lab
