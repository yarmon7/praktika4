#pragma once
#include <QByteArray>
#include <QString>
#include <optional>

namespace Lab {
constexpr quint16 StationPort = 14540, SimulatorPort = 14551;
constexpr quint8 StationId = 255, StationComponent = 190, UavId = 1, UavComponent = 1;
constexpr quint16 Land = 21, Takeoff = 22;
enum class Message : quint32 { Heartbeat = 0, Position = 33, Command = 76, Ack = 77 };

struct Frame {
    Message type;
    quint8 seq, system, component;
    QByteArray payload;
};
struct Position {
    quint32 bootMs;
    double latitude, longitude, altitude, verticalSpeed;
};
struct Heartbeat {
    quint32 mode;
    bool sensorFailed;
};
struct Command {
    quint16 id;
    float altitude;
    quint8 targetSystem, targetComponent;
};
struct Ack {
    quint16 command;
    quint8 result, targetSystem, targetComponent;
};

// One unsigned MAVLink 2 frame per UDP datagram in the lab.
class MavlinkMessageParser {
public:
    static QByteArray encode(const Frame &frame);
    static std::optional<Frame> decode(const QByteArray &data, QString &error);
    static QByteArray heartbeatPayload(quint32 mode, bool sensorFailed);
    static QByteArray positionPayload(const Position &p);
    static QByteArray commandPayload(quint16 id, float altitude);
    static QByteArray ackPayload(quint16 command, quint8 result, quint8 targetSys, quint8 targetComp);
    static Heartbeat heartbeat(const Frame &frame);
    static Position position(const Frame &frame);
    static Command command(const Frame &frame);
    static Ack ack(const Frame &frame);
};
} // namespace Lab
