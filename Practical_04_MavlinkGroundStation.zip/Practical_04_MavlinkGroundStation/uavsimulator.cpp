#include "uavsimulator.h"
#include <QNetworkDatagram>
#include <algorithm>
#include <cmath>

namespace Lab {
UavSimulator::UavSimulator(QObject *parent) : QObject(parent)
{
    m_boot.start();
    m_timer.setInterval(100);
    m_timer.setTimerType(Qt::PreciseTimer);
    connect(&m_timer, &QTimer::timeout, this, &UavSimulator::tick);
    connect(&m_socket, &QUdpSocket::readyRead, this, &UavSimulator::readCommands);
}
bool UavSimulator::start(quint16 stationPort, quint16 localPort)
{
    if (running()) return true;
    if (!m_socket.bind(QHostAddress::LocalHost, localPort, QUdpSocket::DontShareAddress)) {
        emit status(QString("Не удалось открыть порт %1 — %2").arg(localPort).arg(m_socket.errorString()));
        return false;
    }
    m_stationPort = stationPort;
    m_untilHeartbeat = 0;
    m_step.start();
    m_timer.start();
    emit status(QString("Передача с порта %1 на 127.0.0.1:%2").arg(m_socket.localPort()).arg(stationPort));
    tick();
    return true;
}
void UavSimulator::stop()
{
    m_timer.stop();
    m_socket.close();
    m_skip = 0;
    m_corrupt = m_omitAck = false;
    emit status("Передача остановлена");
}
void UavSimulator::setInterval(int ms)
{
    m_timer.setInterval(std::clamp(ms, 100, 2000));
    m_untilHeartbeat = 0;
}
void UavSimulator::setSensorFailed(bool failed)
{
    m_failed = failed;
    m_untilHeartbeat = 0;
}
void UavSimulator::tick()
{
    const double dt = m_step.restart() / 1000.0;
    const double previous = m_height;
    if (!m_failed)
        m_height += std::clamp(m_target - m_height, -5.0 * dt, 8.0 * dt);
    const double speed = dt > 0 ? (m_height - previous) / dt : 0;
    const auto mode = m_target > m_height ? Climb : m_target < m_height ? Descent :
                      m_height > 0 ? Hold : Ground;
    if (m_untilHeartbeat == 0 || m_failed) {
        send(Message::Heartbeat, Parser::heartbeatPayload(mode, m_failed));
        m_untilHeartbeat = std::max(1, qRound(1000.0 / m_timer.interval()) - 1);
    } else {
        --m_untilHeartbeat;
        send(Message::Position, Parser::positionPayload(
            {quint32(m_boot.elapsed()), 55.75222, 37.61556, m_height, speed}));
    }
}
void UavSimulator::send(Message type, const QByteArray &payload)
{
    auto data = Parser::encode({type, m_seq++, UavId, UavComponent, payload});
    if (type != Message::Ack && m_skip > 0) {
        --m_skip;
        return;
    }
    if (type != Message::Ack && m_corrupt) {
        data[data.size() - 1] ^= char(0x40);
        m_corrupt = false;
    }
    if (m_socket.writeDatagram(data, QHostAddress::LocalHost, m_stationPort) != data.size())
        emit status("Ошибка отправки — " + m_socket.errorString());
}
void UavSimulator::readCommands()
{
    while (m_socket.hasPendingDatagrams()) {
        const auto d = m_socket.receiveDatagram();
        if (!d.isValid() || !d.senderAddress().isLoopback() || d.senderPort() != m_stationPort) continue;
        QString error;
        const auto f = Parser::decode(d.data(), error);
        if (!f || f->type != Message::Command || f->system != StationId || f->component != StationComponent)
            continue;
        const auto cmd = Parser::command(*f);
        if (cmd.targetSystem != UavId || cmd.targetComponent != UavComponent) continue;
        quint8 result = 0;
        if (m_failed) result = 2; // DENIED
        else if (cmd.id == Land) m_target = 0;
        else if (cmd.id != Takeoff) result = 3; // UNSUPPORTED
        else if (!std::isfinite(cmd.altitude) || cmd.altitude < 10 || cmd.altitude > 500) result = 2;
        else m_target = cmd.altitude;
        m_untilHeartbeat = 0;
        if (m_omitAck) {
            m_omitAck = false;
            emit status(QString("Команда %1 получена, ACK пропущен").arg(cmd.id));
        } else {
            send(Message::Ack, Parser::ackPayload(cmd.id, result, f->system, f->component));
            emit status(QString("Команда %1 · COMMAND_ACK %2").arg(cmd.id).arg(result));
        }
    }
}
} // namespace Lab
