#pragma once
#include "telemetrymodel.h"
#include <QDateTime>
#include <QElapsedTimer>
#include <QTimer>
#include <QUdpSocket>
#include <deque>

namespace Lab {
enum class Quality { Low, Medium, High };
class MavlinkManager : public QObject {
    Q_OBJECT
public:
    explicit MavlinkManager(TelemetryModel &model, QObject *parent = nullptr);
    bool start(quint16 port = StationPort);
    void stop();
    void sendCommand(quint16 command, double altitude = 0);
    bool isOpen() const { return m_socket.state() == QAbstractSocket::BoundState; }
    quint64 received() const { return m_received; }
    quint64 lost() const { return m_lost; }
    quint64 errors() const { return m_errors; }
    double rate() const { return m_rate; }
    static Quality qualityFor(double rate, bool online);
    QDateTime firstPacket() const { return m_firstPacket; }
    QDateTime lastPacket() const { return m_lastPacket; }
    QString sender() const;
    bool waitingAck() const { return m_pending.has_value(); }
    const QString &commandStatus() const { return m_commandStatus; }
signals:
    void changed();
    void event(const QString &type, const QString &message);
    void linkLost();
    void newStream();
private:
    void readPending();
    void refreshQuality();
    void loseLink();
    void receiveAck(const Ack &ack);
    void finishCommand(const QString &text);
    TelemetryModel &m_model;
    QUdpSocket m_socket;
    QTimer m_qualityTimer, m_silenceTimer, m_ackTimer;
    QElapsedTimer m_clock;
    std::deque<qint64> m_recent;
    QDateTime m_firstPacket, m_lastPacket;
    QHostAddress m_address;
    quint16 m_port = 0;
    quint64 m_received = 0, m_lost = 0, m_errors = 0;
    double m_rate = 0;
    qint64 m_lastArrival = -1;
    int m_lastSeq = -1;
    quint8 m_txSeq = 0;
    std::optional<quint16> m_pending;
    QString m_commandStatus = "Команд ещё не было";
};
} // namespace Lab
