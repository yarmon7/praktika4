#include "mainwindow.h"
#include "uavsimulator.h"
#include <QtTest>
#include <QChartView>
#include <QDoubleSpinBox>
#include <QLabel>
#include <QListWidget>
#include <QMessageBox>
#include <QPushButton>

using namespace Lab;
using Parser = MavlinkMessageParser;

class PracticalTests : public QObject {
    Q_OBJECT
private slots:
    void protocolAndThresholds()
    {
        // Fixed HEARTBEAT reference, checksum calculated separately with polynomial 0x8408.
        const auto raw = QByteArray::fromHex("fd090000ff01010000000200000002000104036a34");
        QString error;
        const auto frame = Parser::decode(raw, error);
        QVERIFY(frame);
        QCOMPARE(Parser::heartbeat(*frame).mode, quint32(Hold));
        QCOMPARE(Parser::encode(*frame), raw);
        QVERIFY(!Parser::decode(raw.chopped(1), error));
        QCOMPARE(MavlinkManager::qualityFor(0.5, true), Quality::Low);
        QCOMPARE(MavlinkManager::qualityFor(1, true), Quality::Medium);
        QCOMPARE(MavlinkManager::qualityFor(5, true), Quality::Medium);
        QCOMPARE(MavlinkManager::qualityFor(6, true), Quality::High);
        QCOMPARE(MavlinkManager::qualityFor(10, false), Quality::Low);
    }

    void badPacketsAndSequence()
    {
        TelemetryModel model;
        MavlinkManager link(model);
        QVERIFY(link.start());
        QUdpSocket sender;
        auto transmit = [&](int seq, double height, bool corrupt = false) {
            auto data = Parser::encode({Message::Position, quint8(seq), UavId, UavComponent,
                            Parser::positionPayload({100, 55.75, 37.61, height, -2.5})});
            if (corrupt) data[10] ^= 1;
            return sender.writeDatagram(data, QHostAddress::LocalHost, StationPort) == data.size();
        };
        QVERIFY(transmit(10, 7));
        QTRY_COMPARE(link.received(), 1u);
        QVERIFY(transmit(13, 12));
        QTRY_COMPARE(link.lost(), 2u);
        QVERIFY(transmit(14, 200, true));
        QTRY_COMPARE(link.errors(), 1u);
        QCOMPARE(model.position()->altitude, 12.0);
        QVERIFY(transmit(15, 13));
        QTRY_COMPARE(model.position()->altitude, 13.0);
        QCOMPARE(model.position()->verticalSpeed, -2.5);
        QVERIFY(transmit(14, 200)); // late frame cannot rewind the chart
        QTRY_COMPARE(link.received(), 4u);
        QCOMPARE(model.position()->altitude, 13.0);
        QVERIFY(transmit(135, 14));
        QVERIFY(transmit(255, 15));
        QVERIFY(transmit(0, 16));
        QTRY_COMPARE(model.position()->altitude, 16.0);
        QCOMPARE(link.lost(), 241u);
    }

    void simulatorCommands()
    {
        TelemetryModel model;
        MavlinkManager link(model);
        UavSimulator sim;
        link.sendCommand(Takeoff, 80);
        QVERIFY(link.commandStatus().contains("нет связи"));
        QVERIFY(link.start());
        QVERIFY(sim.start());
        QTRY_VERIFY(model.position().has_value());
        QTRY_VERIFY_WITH_TIMEOUT(link.rate() > 5, 4000);
        link.sendCommand(Takeoff, 80);
        QVERIFY(link.waitingAck());
        QTRY_COMPARE(link.commandStatus(), QString("Команда принята"));
        QTRY_VERIFY(model.position()->verticalSpeed > 0);
        link.sendCommand(Land);
        QTRY_VERIFY(model.position()->verticalSpeed < 0);
        QTRY_VERIFY(model.position()->altitude == 0 && model.position()->verticalSpeed == 0);
        sim.suppressNextAck();
        QElapsedTimer clock;
        clock.start();
        link.sendCommand(Takeoff, 10);
        QTRY_COMPARE_WITH_TIMEOUT(link.commandStatus(), QString("Подтверждение не получено"), 4000);
        QVERIFY(clock.elapsed() >= 3000);
        QTRY_VERIFY(model.position()->altitude == 10 && model.position()->verticalSpeed == 0);
        sim.setSensorFailed(true);
        QTRY_VERIFY(model.heartbeat()->sensorFailed);
        link.sendCommand(Takeoff, 80);
        QTRY_COMPARE(link.commandStatus(), QString("Команда отклонена"));
        sim.setSensorFailed(false);
        QTRY_VERIFY(!model.heartbeat()->sensorFailed);
    }

    void stationWindow()
    {
        MainWindow window;
        window.show();
        auto label = [&](const char *id) { return window.findChild<QLabel *>(id)->text(); };
        auto button = [&](const char *id) { return window.findChild<QPushButton *>(id); };
        auto *log = window.findChild<QListWidget *>("listCommandLog");
        QCOMPARE(label("labelLinkStatus"), QString("Связь отсутствует"));
        QVERIFY(!button("btnTakeoff")->isEnabled());
        button("btnStartLink")->click();
        QCOMPARE(label("labelLinkStatus"), QString("Ожидание БПЛА"));
        UavSimulator sim;
        QVERIFY(sim.start());
        QTRY_COMPARE(label("labelLinkStatus"), QString("Связь установлена"));
        QTRY_VERIFY(label("labelLatitude").contains("55.7522200"));
        QVERIFY(label("labelSender").endsWith(":14551"));
        sim.skipTwoPackets();
        QTRY_VERIFY(label("labelPackets").endsWith("/ 2"));
        sim.corruptNextPacket();
        QTRY_COMPARE(label("labelErrors"), QString("1"));
        QVERIFY(!log->findItems("CRC", Qt::MatchContains).isEmpty());
        window.findChild<QDoubleSpinBox *>("spinTakeoffAltitude")->setValue(80);
        button("btnTakeoff")->click();
        QTRY_COMPARE(label("labelCommandStatus"), QString("Команда принята"));
        QTRY_VERIFY(label("labelSpeed").contains("8.0"));
        QCOMPARE(window.findChild<QChartView *>()->chart()->series().size(), 2);
        int warnings = 0;
        QTimer dismiss;
        connect(&dismiss, &QTimer::timeout, &window, [&] {
            if (auto *box = qobject_cast<QMessageBox *>(QApplication::activeModalWidget())) {
                ++warnings;
                box->accept();
            }
        });
        dismiss.start(20);
        for (int i = 0; i < 2; ++i) {
            sim.stop();
            QTRY_COMPARE_WITH_TIMEOUT(label("labelLinkStatus"), QString("Связь потеряна"), 4100);
            QVERIFY(!button("btnTakeoff")->isEnabled());
            QCOMPARE(warnings, 1);
            QVERIFY(sim.start());
            QTRY_VERIFY(button("btnTakeoff")->isEnabled());
        }
        QCOMPARE(log->findItems("Связь потеряна", Qt::MatchContains).size(), 2);
        button("btnStopLink")->click();
        QVERIFY(!button("btnLand")->isEnabled());
    }

    void launchSeparateEmulator()
    {
        MainWindow window;
        window.show();
        window.findChild<QPushButton *>("btnStartLink")->click();
        window.findChild<QPushButton *>("btnSimulator")->click();
        auto *takeoff = window.findChild<QPushButton *>("btnTakeoff");
        QTRY_VERIFY_WITH_TIMEOUT(takeoff->isEnabled(), 5000);
        takeoff->click();
        auto *status = window.findChild<QLabel *>("labelCommandStatus");
        QTRY_COMPARE(status->text(), QString("Команда принята"));
        auto *altitude = window.findChild<QLabel *>("labelAltitude");
        QTRY_VERIFY(altitude->text() != "—" && altitude->text() != "0.0 м");
    }
};

QTEST_MAIN(PracticalTests)
#include "practical04_tests.moc"
