#pragma once
#include "uavsimulator.h"
#include <QWidget>
class SimulatorWindow : public QWidget {
public:
    SimulatorWindow();
private:
    Lab::UavSimulator m_simulator;
};
